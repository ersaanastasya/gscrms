<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('articles', function (Blueprint $table) {

            $table->id();

            $table->foreignId('user_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->string('title');

            $table->text('content');

            $table->string('image')->nullable();

            $table->enum('status',[
                'Draft',
                'Published'
            ])->default('Draft');

            $table->timestamps();

        });
    }

    public function down(): void
    {
        Schema::dropIfExists('articles');
    }
};