<nav class="navbar navbar-expand-lg bg-white shadow-sm fixed-top border-bottom">

    <div class="container-fluid px-4">

        <!-- Sidebar Toggle -->
        <button class="btn border-0 me-3" id="sidebarToggle">
            <i class="bi bi-list fs-3"></i>
        </button>

        <!-- Logo -->
        <a href="{{ route('dashboard') }}" class="navbar-brand fw-bold d-flex align-items-center">

            <i class="bi bi-globe2 text-primary fs-3 me-2"></i>

            <div>

                <div class="fw-bold text-dark">
                    GSCRMS
                </div>

                <small class="text-secondary" style="font-size:11px;">
                    Global Supply Chain Risk Monitoring System
                </small>

            </div>

        </a>

        <!-- Mobile Toggle -->
        <button class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarContent">

            <span class="navbar-toggler-icon"></span>

        </button>

        <div class="collapse navbar-collapse" id="navbarContent">

            <!-- Search -->
            <div class="mx-auto w-50">

                <div class="input-group">

                    <span class="input-group-text bg-light border-end-0">

                        <i class="bi bi-search"></i>

                    </span>

                    <input
                        type="text"
                        class="form-control border-start-0"
                        placeholder="Search country, port, news..."
                    >

                </div>

            </div>

            <!-- Right Menu -->
            <ul class="navbar-nav ms-auto align-items-center">

                <!-- Notification -->
                <li class="nav-item dropdown me-3">

                    <a class="nav-link position-relative"
                       href="#"
                       data-bs-toggle="dropdown">

                        <i class="bi bi-bell fs-5"></i>

                        <span
                            class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">

                            3

                        </span>

                    </a>

                    <ul class="dropdown-menu dropdown-menu-end shadow">

                        <li>

                            <h6 class="dropdown-header">

                                Notifications

                            </h6>

                        </li>

                        <li>

                            <a class="dropdown-item" href="#">

                                High Risk Country Updated

                            </a>

                        </li>

                        <li>

                            <a class="dropdown-item" href="#">

                                Weather Updated

                            </a>

                        </li>

                        <li>

                            <a class="dropdown-item" href="#">

                                Exchange Rate Updated

                            </a>

                        </li>

                    </ul>

                </li>

                <!-- User -->
                <li class="nav-item dropdown">

                    <a class="nav-link dropdown-toggle d-flex align-items-center"
                       href="#"
                       data-bs-toggle="dropdown">

                        <img
                            src="https://ui-avatars.com/api/?name={{ urlencode(Auth::user()->name ?? 'User') }}&background=2563EB&color=fff"
                            width="40"
                            height="40"
                            class="rounded-circle me-2"
                            alt="User">

                        <div class="text-start">

                            <div class="fw-semibold">

                                {{ Auth::user()->name ?? 'Guest' }}

                            </div>

                            <small class="text-secondary">

                                Administrator

                            </small>

                        </div>

                    </a>

                    <ul class="dropdown-menu dropdown-menu-end shadow">

                        <li>

                            <a class="dropdown-item" href="#">

                                <i class="bi bi-person me-2"></i>

                                Profile

                            </a>

                        </li>

                        <li>

                            <a class="dropdown-item" href="#">

                                <i class="bi bi-gear me-2"></i>

                                Settings

                            </a>

                        </li>

                        <li>

                            <hr class="dropdown-divider">

                        </li>

                        <li>

                            <form method="POST" action="{{ route('logout') }}">

                                @csrf

                                <button class="dropdown-item">

                                    <i class="bi bi-box-arrow-right me-2"></i>

                                    Logout

                                </button>

                            </form>

                        </li>

                    </ul>

                </li>

            </ul>

        </div>

    </div>

</nav>