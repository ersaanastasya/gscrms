<footer class="footer border-top bg-white py-3 mt-4">

    <div class="container-fluid">

        <div class="row align-items-center">

            <!-- Left -->

            <div class="col-md-6 text-center text-md-start">

                <span class="text-secondary">

                    © {{ date('Y') }}

                    <strong>GSCRMS</strong>

                    | Global Supply Chain Risk Monitoring System

                </span>

            </div>

            <!-- Right -->

            <div class="col-md-6 text-center text-md-end">

                <span class="text-secondary">

                    Version 1.0.0

                </span>

            </div>

        </div>

    </div>

</footer>