@extends('layouts.app')

@section('title', 'Dashboard')

@section('page-title', 'Dashboard')

@section('page-description', 'Global Supply Chain Risk Monitoring System')

@section('breadcrumb')

<li class="breadcrumb-item">
    Home
</li>

<li class="breadcrumb-item active">
    Dashboard
</li>

@endsection

@section('content')

<div class="container-fluid">

    <!-- =======================================================
        TOP STATISTICS
    ======================================================== -->

    <div class="row g-4 mb-4">

        <!-- Total Countries -->

        <div class="col-xl-3 col-lg-6">

            <div class="card stat-card h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small class="text-secondary">

                                Total Countries

                            </small>

                            <h2 class="mt-2 fw-bold">

                                {{ $totalCountries }}

                            </h2>

                        </div>

                        <div class="icon-box bg-primary">

                            <i class="bi bi-globe2"></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <!-- High Risk -->

        <div class="col-xl-3 col-lg-6">

            <div class="card stat-card h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small class="text-secondary">

                                High Risk Countries

                            </small>

                            <h2 class="mt-2 fw-bold text-danger">

                                {{ $highRiskCountries }}

                            </h2>

                        </div>

                        <div class="icon-box bg-danger">

                            <i class="bi bi-exclamation-triangle"></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <!-- Average Risk -->

        <div class="col-xl-3 col-lg-6">

            <div class="card stat-card h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small class="text-secondary">

                                Average Risk

                            </small>

                            <h2 class="mt-2 fw-bold">

                                {{ $averageRiskScore }}

                            </h2>

                        </div>

                        <div class="icon-box bg-warning">

                            <i class="bi bi-speedometer2"></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <!-- News -->

        <div class="col-xl-3 col-lg-6">

            <div class="card stat-card h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small class="text-secondary">

                                Today's News

                            </small>

                            <h2 class="mt-2 fw-bold">

                                {{ $todayNews }}

                            </h2>

                        </div>

                        <div class="icon-box bg-success">

                            <i class="bi bi-newspaper"></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>
        <!-- =======================================================
        MAP + RISK SCORE
    ======================================================== -->

    <div class="row g-4 mb-4">

        <!-- World Map -->

        <div class="col-xl-8">

            <div class="card h-100">

                <div class="card-header bg-white border-0">

                    <h5 class="mb-0 fw-bold">

                        Global Weather Monitoring

                    </h5>

                </div>

                <div class="card-body">

                    <div id="worldMap"
                         style="height:450px;border-radius:12px;">

                    </div>

                </div>

            </div>

        </div>

        <!-- Risk Score -->

        <div class="col-xl-4">

            <div class="card mb-4">

                <div class="card-header bg-white border-0">

                    <h5 class="fw-bold">

                        Risk Score

                    </h5>

                </div>

                <div class="card-body text-center">

                    <div
                        class="rounded-circle border border-5 border-success
                               d-flex align-items-center justify-content-center
                               mx-auto"
                        style="width:180px;height:180px;">

                        <div>

                            <h1 class="fw-bold mb-0">

                                {{ $riskScore['score'] ?? '--' }}

                            </h1>

                            <small class="text-secondary">

                                {{ $riskScore['level'] ?? 'No Data' }}

                            </small>

                        </div>

                    </div>

                    <hr>

                    <div class="row text-center">

                        <div class="col-6">

                            <small class="text-secondary">

                                Weather

                            </small>

                            <h6>

                                {{ $riskScore['weather'] ?? '-' }}

                            </h6>

                        </div>

                        <div class="col-6">

                            <small class="text-secondary">

                                Currency

                            </small>

                            <h6>

                                {{ $riskScore['currency'] ?? '-' }}

                            </h6>

                        </div>

                    </div>

                </div>

            </div>

            <!-- Selected Country -->

            <div class="card">

                <div class="card-header bg-white border-0">

                    <h5 class="fw-bold">

                        Selected Country

                    </h5>

                </div>

                <div class="card-body">

                    <form>

                      <select class="form-select" id="countrySelect">

                            @foreach($countries as $country)

                                <option value="{{ $country->country_code }}">

                                    {{ $country->country_name }}

                                </option>

                            @endforeach

                        </select>

                    </form>

                    <hr>

                    <p class="mb-2">

                        GDP :

                        <strong>

                            {{ $statistics['gdp'] ?? '-' }}

                        </strong>

                    </p>

                    <p class="mb-2">

                        Inflation :

                        <strong>

                            {{ $statistics['inflation'] ?? '-' }}

                        </strong>

                    </p>

                    <p class="mb-0">

                        Population :

                        <strong>

                            {{ $statistics['population'] ?? '-' }}

                        </strong>

                    </p>

                </div>

            </div>

        </div>

    </div>

    <!-- =======================================================
        WEATHER + CURRENCY
    ======================================================== -->

    <div class="row g-4 mb-4">

        <!-- Weather -->

        <div class="col-xl-6">

            <div class="card h-100">

                <div class="card-header bg-white border-0">

                    <h5 class="fw-bold">

                        Current Weather

                    </h5>

                </div>

                <div class="card-body">

                    <div class="row align-items-center">

                        <div class="col-4 text-center">

                            <i class="bi bi-cloud-sun"
                               style="font-size:70px;color:#f59e0b;"></i>

                        </div>

                        <div class="col-8">

                            <h3>

                                {{ $weather['temperature'] ?? '--' }} °C

                            </h3>

                            <p>

                                {{ $weather['condition'] ?? '-' }}

                            </p>

                            <p>

                                Wind :

                                {{ $weather['wind'] ?? '-' }}

                            </p>

                            <p>

                                Humidity :

                                {{ $weather['humidity'] ?? '-' }}

                            </p>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <!-- Currency -->

        <div class="col-xl-6">

            <div class="card h-100">

                <div class="card-header bg-white border-0">

                    <h5 class="fw-bold">

                        Currency Exchange

                    </h5>

                </div>

                <div class="card-body">

                    <h2 class="fw-bold">

                        {{ $currency['rate'] ?? '-' }}

                    </h2>

                    <p>

                        {{ $currency['base'] ?? '-' }}

                        →

                        {{ $currency['target'] ?? '-' }}

                    </p>

                    <canvas id="currencyChart"
                            height="130">

                    </canvas>

                </div>

            </div>

        </div>

    </div>
        <!-- =======================================================
        CHARTS
    ======================================================== -->

    <div class="row g-4 mb-4">

        <!-- GDP Trend -->

        <div class="col-xl-6">

            <div class="card h-100">

                <div class="card-header bg-white border-0">

                    <div class="d-flex justify-content-between align-items-center">

                        <h5 class="fw-bold mb-0">

                            GDP Trend

                        </h5>

                        <span class="badge bg-primary">

                            World Bank

                        </span>

                    </div>

                </div>

                <div class="card-body">

                    <canvas id="gdpChart"
                            height="120">

                    </canvas>

                </div>

            </div>

        </div>

        <!-- Inflation Trend -->

        <div class="col-xl-6">

            <div class="card h-100">

                <div class="card-header bg-white border-0">

                    <div class="d-flex justify-content-between align-items-center">

                        <h5 class="fw-bold mb-0">

                            Inflation Trend

                        </h5>

                        <span class="badge bg-warning">

                            %

                        </span>

                    </div>

                </div>

                <div class="card-body">

                    <canvas id="inflationChart"
                            height="120">

                    </canvas>

                </div>

            </div>

        </div>

    </div>



    <div class="row g-4 mb-4">

        <!-- Currency Trend -->

        <div class="col-xl-6">

            <div class="card h-100">

                <div class="card-header bg-white border-0">

                    <div class="d-flex justify-content-between align-items-center">

                        <h5 class="fw-bold mb-0">

                            Currency Trend

                        </h5>

                        <span class="badge bg-success">

                            Exchange Rate

                        </span>

                    </div>

                </div>

                <div class="card-body">

                    <canvas id="exchangeChart"
                            height="120">

                    </canvas>

                </div>

            </div>

        </div>

        <!-- Risk Trend -->

        <div class="col-xl-6">

            <div class="card h-100">

                <div class="card-header bg-white border-0">

                    <div class="d-flex justify-content-between align-items-center">

                        <h5 class="fw-bold mb-0">

                            Risk Trend

                        </h5>

                        <span class="badge bg-danger">

                            Risk Engine

                        </span>

                    </div>

                </div>

                <div class="card-body">

                    <canvas id="riskChart"
                            height="120">

                    </canvas>

                </div>

            </div>

        </div>

    </div>
        <!-- =======================================================
        NEWS & PORTS
    ======================================================== -->

    <div class="row g-4 mb-4">

        <!-- Latest News -->

        <div class="col-xl-8">

            <div class="card h-100">

                <div class="card-header bg-white border-0">

                    <div class="d-flex justify-content-between align-items-center">

                        <h5 class="fw-bold mb-0">

                            Latest News Intelligence

                        </h5>

                        <a href="#" class="btn btn-sm btn-primary">

                            View All

                        </a>

                    </div>

                </div>

                <div class="card-body">

                    @forelse($news as $item)

                        <div class="news-item py-3 border-bottom">

                            <div class="d-flex justify-content-between">

                                <div>

                                    <h6 class="fw-semibold">

                                        {{ $item['title'] }}

                                    </h6>

                                    <p class="mb-2 text-secondary">

                                        {{ $item['description'] }}

                                    </p>

                                    <small class="text-muted">

                                        {{ $item['source'] }}

                                    </small>

                                </div>

                                <div class="text-end">

                                    <small class="text-muted">

                                        {{ $item['published_at'] }}

                                    </small>

                                </div>

                            </div>

                        </div>

                    @empty

                        <div class="text-center py-5">

                            <i class="bi bi-newspaper fs-1 text-secondary"></i>

                            <p class="mt-3">

                                No News Available

                            </p>

                        </div>

                    @endforelse

                </div>

            </div>

        </div>

        <!-- Top Ports -->

        <div class="col-xl-4">

            <div class="card h-100">

                <div class="card-header bg-white border-0">

                    <h5 class="fw-bold mb-0">

                        Top Ports

                    </h5>

                </div>

                <div class="card-body">

                    @forelse($ports as $port)

                        <div class="d-flex justify-content-between align-items-center py-3 border-bottom">

                            <div>

                                <strong>

                                    {{ $port['name'] }}

                                </strong>

                                <br>

                                <small class="text-secondary">

                                    {{ $port['country'] }}

                                </small>

                            </div>

                            <span class="badge bg-success">

                                Active

                            </span>

                        </div>

                    @empty

                        <div class="text-center py-5">

                            <i class="bi bi-geo-alt fs-1 text-secondary"></i>

                            <p class="mt-3">

                                No Port Data

                            </p>

                        </div>

                    @endforelse

                </div>

            </div>

        </div>

    </div>



    <!-- =======================================================
        COUNTRY SUMMARY
    ======================================================== -->

    <div class="row g-4 mb-4">

        <div class="col-12">

            <div class="card">

                <div class="card-header bg-white border-0">

                    <h5 class="fw-bold">

                        Country Summary

                    </h5>

                </div>

                <div class="card-body">

                    <div class="row text-center">

                        <div class="col-md-3">

                            <h6 class="text-secondary">

                                Capital

                            </h6>

                            <h5>

                                {{ $selectedCountry['capital'] ?? '-' }}

                            </h5>

                        </div>

                        <div class="col-md-3">

                            <h6 class="text-secondary">

                                Currency

                            </h6>

                            <h5>

                                {{ $selectedCountry['currency'] ?? '-' }}

                            </h5>

                        </div>

                        <div class="col-md-3">

                            <h6 class="text-secondary">

                                Population

                            </h6>

                            <h5>

                                {{ $statistics['population'] ?? '-' }}

                            </h5>

                        </div>

                        <div class="col-md-3">

                            <h6 class="text-secondary">

                                Region

                            </h6>

                            <h5>

                                {{ $selectedCountry['region'] ?? '-' }}

                            </h5>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>
        <!-- =======================================================
        HIGH RISK COUNTRIES & GLOBAL STATISTICS
    ======================================================== -->

    <div class="row g-4 mb-4">

        <!-- High Risk Countries -->

        <div class="col-xl-6">

            <div class="card h-100">

                <div class="card-header bg-white border-0 d-flex justify-content-between align-items-center">

                    <h5 class="fw-bold mb-0">
                        High Risk Countries
                    </h5>

                    <span class="badge bg-danger">
                        Live
                    </span>

                </div>

                <div class="card-body">

                    @if(isset($highRiskList) && count($highRiskList))

                        @foreach($highRiskList as $country)

                            <div class="d-flex justify-content-between align-items-center py-3 border-bottom">

                                <div class="d-flex align-items-center">

                                    <div class="me-3">

                                        <img
                                            src="{{ $country['flag'] }}"
                                            width="42"
                                            class="rounded shadow-sm"
                                            alt="{{ $country['country'] }}">

                                    </div>

                                    <div>

                                        <strong>

                                            {{ $country['country'] }}

                                        </strong>

                                        <br>

                                        <small class="text-secondary">

                                            {{ $country['risk_level'] }}

                                        </small>

                                    </div>

                                </div>

                                <span class="badge bg-danger">

                                    {{ $country['risk_score'] }}

                                </span>

                            </div>

                        @endforeach

                    @else

                        <div class="text-center py-5">

                            <i class="bi bi-shield-exclamation fs-1 text-secondary"></i>

                            <p class="mt-3">

                                No High Risk Data

                            </p>

                        </div>

                    @endif

                </div>

            </div>

        </div>

        <!-- Global Statistics -->

        <div class="col-xl-6">

            <div class="card h-100">

                <div class="card-header bg-white border-0">

                    <h5 class="fw-bold">

                        Global Statistics

                    </h5>

                </div>

                <div class="card-body">

                    <table class="table table-borderless align-middle">

                        <tbody>

                            <tr>

                                <td>Total Countries</td>

                                <td class="text-end fw-bold">

                                    {{ $totalCountries }}

                                </td>

                            </tr>

                            <tr>

                                <td>High Risk</td>

                                <td class="text-end text-danger fw-bold">

                                    {{ $highRiskCountries }}

                                </td>

                            </tr>

                            <tr>

                                <td>Medium Risk</td>

                                <td class="text-end text-warning fw-bold">

                                    {{ $mediumRiskCountries ?? 0 }}

                                </td>

                            </tr>

                            <tr>

                                <td>Low Risk</td>

                                <td class="text-end text-success fw-bold">

                                    {{ $lowRiskCountries ?? 0 }}

                                </td>

                            </tr>

                            <tr>

                                <td>Average Risk Score</td>

                                <td class="text-end fw-bold">

                                    {{ $averageRiskScore }}

                                </td>

                            </tr>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>



    <!-- =======================================================
        RECENT ALERTS
    ======================================================== -->

    <div class="row g-4 mb-4">

        <div class="col-12">

            <div class="card">

                <div class="card-header bg-white border-0 d-flex justify-content-between align-items-center">

                    <h5 class="fw-bold mb-0">

                        Recent Alerts

                    </h5>

                    <button class="btn btn-primary btn-sm">

                        View All

                    </button>

                </div>

                <div class="card-body">

                    @if(isset($alerts) && count($alerts))

                        @foreach($alerts as $alert)

                            <div class="alert alert-warning mb-3">

                                <div class="d-flex justify-content-between">

                                    <div>

                                        <strong>

                                            {{ $alert['country'] }}

                                        </strong>

                                        <br>

                                        {{ $alert['message'] }}

                                    </div>

                                    <small>

                                        {{ $alert['time'] }}

                                    </small>

                                </div>

                            </div>

                        @endforeach

                    @else

                        <div class="text-center py-5">

                            <i class="bi bi-bell fs-1 text-secondary"></i>

                            <p class="mt-3">

                                No Alert

                            </p>

                        </div>

                    @endif

                </div>

            </div>

        </div>

    </div>
        <!-- =======================================================
        SYSTEM MONITORING
    ======================================================== -->

    <div class="row g-4 mb-4">

        <!-- Monitoring Timeline -->

        <div class="col-xl-8">

            <div class="card h-100">

                <div class="card-header bg-white border-0">

                    <h5 class="fw-bold mb-0">

                        Monitoring Activity

                    </h5>

                </div>

                <div class="card-body">

                    @if(isset($activities) && count($activities))

                        @foreach($activities as $activity)

                            <div class="d-flex mb-4">

                                <div class="me-3">

                                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center"
                                         style="width:45px;height:45px;">

                                        <i class="bi bi-activity"></i>

                                    </div>

                                </div>

                                <div class="flex-grow-1">

                                    <strong>

                                        {{ $activity['title'] }}

                                    </strong>

                                    <p class="mb-1 text-secondary">

                                        {{ $activity['description'] }}

                                    </p>

                                    <small class="text-muted">

                                        {{ $activity['time'] }}

                                    </small>

                                </div>

                            </div>

                        @endforeach

                    @else

                        <div class="text-center py-5">

                            <i class="bi bi-clock-history fs-1 text-secondary"></i>

                            <p class="mt-3">

                                No Monitoring Activity

                            </p>

                        </div>

                    @endif

                </div>

            </div>

        </div>

        <!-- API Status -->

        <div class="col-xl-4">

            <div class="card">

                <div class="card-header bg-white border-0">

                    <h5 class="fw-bold">

                        API Status

                    </h5>

                </div>

                <div class="card-body">

                    <table class="table table-borderless">

                        <tbody>

                            <tr>

                                <td>REST Countries</td>

                                <td class="text-end">

                                    <span class="badge bg-success">

                                        Online

                                    </span>

                                </td>

                            </tr>

                            <tr>

                                <td>World Bank</td>

                                <td class="text-end">

                                    <span class="badge bg-success">

                                        Online

                                    </span>

                                </td>

                            </tr>

                            <tr>

                                <td>Open-Meteo</td>

                                <td class="text-end">

                                    <span class="badge bg-success">

                                        Online

                                    </span>

                                </td>

                            </tr>

                            <tr>

                                <td>Exchange Rate</td>

                                <td class="text-end">

                                    <span class="badge bg-success">

                                        Online

                                    </span>

                                </td>

                            </tr>

                            <tr>

                                <td>GNews</td>

                                <td class="text-end">

                                    <span class="badge bg-success">

                                        Online

                                    </span>

                                </td>

                            </tr>

                        </tbody>

                    </table>

                </div>

            </div>

            <div class="card mt-4">

                <div class="card-header bg-white border-0">

                    <h5 class="fw-bold">

                        System Status

                    </h5>

                </div>

                <div class="card-body">

                    <div class="d-flex justify-content-between mb-3">

                        <span>

                            Server

                        </span>

                        <span class="badge bg-success">

                            Running

                        </span>

                    </div>

                    <div class="d-flex justify-content-between mb-3">

                        <span>

                            Database

                        </span>

                        <span class="badge bg-success">

                            Connected

                        </span>

                    </div>

                    <div class="d-flex justify-content-between mb-3">

                        <span>

                            Cache

                        </span>

                        <span class="badge bg-success">

                            Active

                        </span>

                    </div>

                    <div class="d-flex justify-content-between">

                        <span>

                            Scheduler

                        </span>

                        <span class="badge bg-success">

                            Active

                        </span>

                    </div>

                </div>

            </div>

        </div>

    </div>



    <!-- =======================================================
        QUICK ACTION
    ======================================================== -->

    <div class="row g-4 mb-4">

        <div class="col-12">

            <div class="card">

                <div class="card-header bg-white border-0">

                    <h5 class="fw-bold">

                        Quick Action

                    </h5>

                </div>

                <div class="card-body">

                    <div class="row text-center">

                        <div class="col-lg-3 col-md-6 mb-3">

                            <a href="{{ route('countries.index') }}"
                               class="btn btn-primary w-100 py-3">

                                <i class="bi bi-globe2 me-2"></i>

                                Countries

                            </a>

                        </div>

                        <div class="col-lg-3 col-md-6 mb-3">

                            <a href="{{ route('monitoring.index') }}"
                               class="btn btn-success w-100 py-3">

                                <i class="bi bi-activity me-2"></i>

                                Monitoring

                            </a>

                        </div>

                        <div class="col-lg-3 col-md-6 mb-3">

                            <a href="{{ route('comparison.index') }}"
                               class="btn btn-warning w-100 py-3 text-white">

                                <i class="bi bi-bar-chart me-2"></i>

                                Comparison

                            </a>

                        </div>

                        <div class="col-lg-3 col-md-6 mb-3">

                            <a href="{{ route('ports.index') }}"
                               class="btn btn-info w-100 py-3 text-white">

                                <i class="bi bi-geo-alt me-2"></i>

                                Ports

                            </a>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

        <!-- =======================================================
        DASHBOARD INFORMATION
    ======================================================== -->

    <div class="row">

        <div class="col-12">

            <div class="card">

                <div class="card-body">

                    <div class="row align-items-center">

                        <div class="col-lg-6">

                            <h5 class="fw-bold mb-3">

                                Dashboard Information

                            </h5>

                            <table class="table table-borderless">

                                <tbody>

                                    <tr>

                                        <td width="220">

                                            Last Update

                                        </td>

                                        <td>

                                            {{ now()->format('d M Y H:i') }}

                                        </td>

                                    </tr>

                                    <tr>

                                        <td>

                                            Weather Source

                                        </td>

                                        <td>

                                            Open-Meteo API

                                        </td>

                                    </tr>

                                    <tr>

                                        <td>

                                            GDP Source

                                        </td>

                                        <td>

                                            World Bank API

                                        </td>

                                    </tr>

                                    <tr>

                                        <td>

                                            Currency Source

                                        </td>

                                        <td>

                                            Exchange Rate API

                                        </td>

                                    </tr>

                                    <tr>

                                        <td>

                                            News Source

                                        </td>

                                        <td>

                                            GNews API

                                        </td>

                                    </tr>

                                </tbody>

                            </table>

                        </div>

                        <div class="col-lg-6">

                            <div
                                class="rounded-4 border bg-light d-flex align-items-center justify-content-center"
                                style="height:220px;">

                                <div class="text-center">

                                    <i class="bi bi-globe-americas fs-1 text-primary"></i>

                                    <h5 class="mt-3">

                                        Global Supply Chain Risk Monitoring

                                    </h5>

                                    <p>

                                        Real-time Monitoring for 220 Countries

                                    </p>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

@endsection



@push('scripts')

<script>

document.addEventListener('DOMContentLoaded', function () {

    /*
    |--------------------------------------------------------------------------
    | World Map (Leaflet)
    |--------------------------------------------------------------------------
    */

    if (document.getElementById('worldMap')) {

        var map = L.map('worldMap').setView([20,0],2);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{

            attribution:'© OpenStreetMap'

        }).addTo(map);

    }

});
</script>
    /*
|--------------------------------------------------------------------------
| GDP Trend Chart
|--------------------------------------------------------------------------
*/

const gdpCanvas = document.getElementById('gdpChart');

if (gdpCanvas) {

    new Chart(gdpCanvas, {

        type: 'line',

        data: {

            labels: ['2021','2022','2023','2024','2025'],

            datasets: [{

                label: 'GDP',

                data: [0,0,0,0,0],

                borderWidth: 3,

                tension: .4,

                fill: false

            }]

        },

        options: {

            responsive: true,

            maintainAspectRatio: false

        }

    });

}

/*
|--------------------------------------------------------------------------
| Inflation Chart
|--------------------------------------------------------------------------
*/

const inflationCanvas = document.getElementById('inflationChart');

if (inflationCanvas) {

    new Chart(inflationCanvas, {

        type: 'line',

        data: {

            labels: ['2021','2022','2023','2024','2025'],

            datasets: [{

                label: 'Inflation',

                data: [0,0,0,0,0],

                borderWidth: 3,

                tension: .4,

                fill: false

            }]

        },

        options: {

            responsive: true,

            maintainAspectRatio: false

        }

    });

}

/*
|--------------------------------------------------------------------------
| Currency Chart
|--------------------------------------------------------------------------
*/

const currencyCanvas = document.getElementById('currencyChart');

if (currencyCanvas) {

    new Chart(currencyCanvas, {

        type: 'line',

        data: {

            labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],

            datasets: [{

                label: 'Exchange Rate',

                data: [0,0,0,0,0,0,0],

                borderWidth: 3,

                tension: .4,

                fill: false

            }]

        },

        options: {

            responsive: true,

            maintainAspectRatio: false

        }

    });

}

/*
|--------------------------------------------------------------------------
| Risk Chart
|--------------------------------------------------------------------------
*/

const riskCanvas = document.getElementById('riskChart');

if (riskCanvas) {

    new Chart(riskCanvas, {

        type: 'bar',

        data: {

            labels: [

                'Weather',

                'Inflation',

                'Currency',

                'News'

            ],

            datasets: [{

                label: 'Risk Score',

                data: [0,0,0,0],

                borderWidth: 1

            }]

        },

        options: {

            responsive: true,

            maintainAspectRatio: false

        }

    });

}

/*
|--------------------------------------------------------------------------
| Exchange Chart
|--------------------------------------------------------------------------
*/

const exchangeCanvas = document.getElementById('exchangeChart');

if (exchangeCanvas) {

    new Chart(exchangeCanvas, {

        type: 'line',

        data: {

            labels: ['1','2','3','4','5','6','7'],

            datasets: [{

                label: 'Exchange',

                data: [0,0,0,0,0,0,0],

                borderWidth: 3,

                tension: .4,

                fill: false

            }]

        },

        options: {

            responsive: true,

            maintainAspectRatio: false

        }

    });

}

</script>

@endpush