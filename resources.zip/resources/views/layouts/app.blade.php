<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>@yield('title', 'GSCRMS')</title>

    @vite([
        'resources/css/app.css',
        'resources/js/app.js'
    ])

</head>

<body>

<div class="wrapper">

    {{-- Navbar --}}
    @include('partials.navbar')

    {{-- Sidebar --}}
    @include('partials.sidebar')

    {{-- Main Content --}}
    <main class="main-content">

        {{-- Page Header --}}
        <div class="page-header mb-4">

            <div>

                <h2 class="page-title">

                    @yield('page-title')

                </h2>

                <p class="page-subtitle">

                    @yield('page-description')

                </p>

            </div>

            {{-- Breadcrumb --}}
            <nav>

                <ol class="breadcrumb mb-0">

                    @yield('breadcrumb')

                </ol>

            </nav>

        </div>

        {{-- Page Content --}}
        <div class="content-wrapper">

            @yield('content')

        </div>

    </main>

</div>

@include('partials.footer')

@stack('scripts')

</body>

</html>